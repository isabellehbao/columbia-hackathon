# Roar Active — Columbia Campus Wellness

A single-page campus wellness prototype for gym attendance and a campus scavenger hunt.

## Run locally

Open `index.html` in a browser. Location checks and camera access work best when served from HTTPS (for example, through GitHub Pages), because browsers restrict these features on local files.

## Publish with GitHub Pages

1. Create a GitHub repository and upload the files in this folder to its root.
2. In the repository, open **Settings → Pages**.
3. Set the source to deploy from the `main` branch and `/ (root)`.
4. Open the published Pages URL over HTTPS.

## Prototype features

- Email and password account creation and login.
- Gym check-in and checkout flow with a weekly leaderboard.
- Admin controls for adding scavenger hunt locations by name and coordinates.
- Five-foot proximity check, photo check-in, and Google Maps links for configured locations.

## Prototype limitations

This is a front-end demo. Data is stored in the current browser, not a shared server, so accounts and leaderboards do not synchronize across devices or users. The administrator password (`12345`) is embedded in the page and is only suitable for this prototype. Do not use real student credentials or sensitive data.

A production deployment needs server-side authentication, authorization, storage, and verification. A normal browser page also cannot reliably detect every phone unlock during a gym session. Google Maps links open configured coordinates; they do not provide live location tracking. The hunt proximity check uses the browser's location API.
